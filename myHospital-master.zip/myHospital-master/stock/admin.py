from django.contrib import admin
from .models import items,stock

# Register your models here.
admin.site.register(items)
admin.site.register(stock)
