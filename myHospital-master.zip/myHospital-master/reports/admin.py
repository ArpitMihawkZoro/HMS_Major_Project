from django.contrib import admin
from .models import Report

# Register your models here.
admin.site.register(Report)
