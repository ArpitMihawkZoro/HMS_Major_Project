from django.apps import AppConfig


class BillConfig(AppConfig):
    name = 'bill'
