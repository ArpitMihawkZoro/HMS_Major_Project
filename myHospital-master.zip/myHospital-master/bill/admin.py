from django.contrib import admin
from .models import bill

# Register your models here.
admin.site.register(bill)
