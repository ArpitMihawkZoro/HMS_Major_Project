from django.apps import AppConfig


class AppointmentsConfig(AppConfig):
    name = 'appointments'
