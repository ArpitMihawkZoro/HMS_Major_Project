from django.contrib import admin
from .models import case

# Register your models here.
admin.site.register(case)
