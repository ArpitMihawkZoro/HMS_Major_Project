from django.apps import AppConfig


class CaseConfig(AppConfig):
    name = 'case'
