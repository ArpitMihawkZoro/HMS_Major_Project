# myHospital
Hospital management system developed using Django framework as a part of Software Project Course

Demo : https://my-hospital.herokuapp.com/

Login Credentials

usernames:
receptionist
doctor
patient
labattendant

password for all:
qwerty123
